'use client'

import { useState } from 'react'
import {
  BarChart3,
  CalendarDays,
  Check,
  ChevronRight,
  CircleHelp,
  Flame,
  Home,
  Mountain,
  Plus,
  ShieldCheck,
  Trophy,
  UserRound,
  WineOff,
  X,
  Zap,
} from 'lucide-react'

const runners = [
  { rank: 1, name: 'Petr Novák', initials: 'PN', points: 842, km: '58.4', elevation: '1 240', sober: 6, progress: 92, color: 'avatar-lime' },
  { rank: 2, name: 'Jana Veselá', initials: 'JV', points: 796, km: '51.2', elevation: '980', sober: 7, progress: 86, color: 'avatar-coral' },
  { rank: 3, name: 'Tomáš Dvořák', initials: 'TD', points: 734, km: '47.8', elevation: '1 105', sober: 5, progress: 79, color: 'avatar-blue' },
  { rank: 4, name: 'Ty', initials: 'TY', points: 688, km: '42.6', elevation: '870', sober: 6, progress: 74, color: 'avatar-violet', current: true },
]

export default function Page() {
  const [activeTab, setActiveTab] = useState('home')
  const [alcoholFree, setAlcoholFree] = useState(true)
  const [submitted, setSubmitted] = useState(false)

  return (
    <main className="app-shell">
      <div className="app-inner">
        <header className="topbar">
          <div className="brand-lockup">
            <div className="brand-mark"><Trophy /></div>
            <div>
              <p className="eyebrow">KOKOTÍ VÝZVA</p>
              <h1>Drž tempo. <span>Drž slovo.</span></h1>
            </div>
          </div>
          <button className="profile-button" aria-label="Otevřít profil"><span>MK</span></button>
        </header>

        {activeTab === 'home' && <>
          <section className="week-card">
            <div>
              <div className="week-label"><span className="live-dot" /> 3. TÝDEN VÝZVY</div>
              <p className="week-title">Ještě 4 dny do cíle</p>
              <p className="week-subtitle">Společně jsme uběhli <strong>200,0 km</strong></p>
            </div>
            <div className="week-ring"><strong>68%</strong><span>hotovo</span></div>
          </section>

          <section className="section-heading">
            <div><p className="eyebrow">TABULKA VÝKONŮ</p><h2>Pořadí <span>týmu</span></h2></div>
            <button className="icon-button" aria-label="Nápověda"><CircleHelp /></button>
          </section>

          <section className="leaderboard" aria-label="Pořadí týmu">
            {runners.map((runner) => <article className={`runner-card ${runner.current ? 'runner-current' : ''}`} key={runner.name}>
              <div className="rank">{runner.rank === 1 ? <Trophy className="rank-trophy" /> : `0${runner.rank}`}</div>
              <div className={`avatar ${runner.color}`}>{runner.initials}</div>
              <div className="runner-main">
                <div className="runner-top"><h3>{runner.name}</h3><strong>{runner.points} <small>bodů</small></strong></div>
                <div className="runner-stats"><span><Zap /> {runner.km} km</span><span><Mountain /> {runner.elevation} m</span><span><WineOff /> {runner.sober} dní</span></div>
                <div className="progress-track"><div style={{ width: `${runner.progress}%` }} /></div>
              </div>
              {runner.current && <span className="you-badge">TY</span>}
            </article>)}
          </section>

          <section className="entry-card">
            <div className="entry-heading"><div><p className="eyebrow">DENNÍ ZÁPIS</p><h2>Přidat <span>dnešek</span></h2></div><div className="date-pill"><CalendarDays /> 21. 9. 2025</div></div>
            <div className="field-row">
              <label><span>VZDÁLENOST</span><div className="input-wrap"><input type="number" defaultValue="5" aria-label="Vzdálenost v kilometrech" /><b>km</b></div></label>
              <label><span>PŘEVÝŠENÍ</span><div className="input-wrap"><input type="number" defaultValue="120" aria-label="Převýšení v metrech" /><b>m</b></div></label>
            </div>
            <button className={`sober-toggle ${alcoholFree ? 'selected' : ''}`} onClick={() => setAlcoholFree(!alcoholFree)} aria-pressed={alcoholFree}>
              <span className="check-box">{alcoholFree && <Check />}</span><span><strong>Den bez alkoholu</strong><small>Počítá se do celkového skóre</small></span><ShieldCheck />
            </button>
            <button className="submit-button" onClick={() => { setSubmitted(true); setTimeout(() => setSubmitted(false), 1800) }}>{submitted ? <><Check /> Zapsáno!</> : <><Plus /> Zapsat aktivitu</>}</button>
          </section>
        </>}

        {activeTab === 'stats' && <section className="placeholder-tab"><div className="big-tab-icon"><BarChart3 /></div><p className="eyebrow">MOJE STATISTIKY</p><h2>Tvoje cesta <span>v číslech</span></h2><p>Historie aktivit a osobní rekordy budou brzy na jednom místě.</p></section>}
        {activeTab === 'info' && <section className="placeholder-tab"><div className="big-tab-icon"><Flame /></div><p className="eyebrow">O VÝZVĚ</p><h2>Každý kilometr <span>se počítá</span></h2><p>Běhej, choď do kopců a sbírej dny bez alkoholu. Na konci týdne vyhrává nejlepší skóre.</p></section>}

        <nav className="bottom-nav" aria-label="Hlavní navigace">
          <button className={activeTab === 'home' ? 'active' : ''} onClick={() => setActiveTab('home')}><Home /><span>Domů</span></button>
          <button className={activeTab === 'stats' ? 'active' : ''} onClick={() => setActiveTab('stats')}><BarChart3 /><span>Statistiky</span></button>
          <button className={activeTab === 'profile' ? 'active' : ''} onClick={() => setActiveTab('profile')}><UserRound /><span>Profil</span></button>
          <button className={activeTab === 'info' ? 'active' : ''} onClick={() => setActiveTab('info')}><CircleHelp /><span>Info</span></button>
        </nav>
      </div>
    </main>
  )
}
